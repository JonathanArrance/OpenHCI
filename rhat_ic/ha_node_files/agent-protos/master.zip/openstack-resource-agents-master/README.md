Pacemaker High Availability resource agents for OpenStack
=========================================================

This project has now moved to OpenStack governance.

Please see: https://launchpad.net/openstack-resource-agents
