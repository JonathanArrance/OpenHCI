# [INSERT 2]
#iceHouse repo
yum install -y http://192.168.10.10/rhat_ic/common/rdo-release-icehouse-4.noarch.rpm