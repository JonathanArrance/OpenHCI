#! /bin/sh

sudo python cn_sn_client.py
