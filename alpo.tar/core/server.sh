#! /bin/sh

sudo python ciac_server.py
