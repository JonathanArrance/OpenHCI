#! /bin/sh

PYTHONPATH="${PYTHONPATH}:/usr/lib/python2.7/site-packages/"

export PYTHONPATH
