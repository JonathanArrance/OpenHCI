#!/bin/rbash
python /home/builder/alpo/interfaces/shell/coalesce.py
