from coalesce.coal_beta.models import *
from django.contrib import admin


