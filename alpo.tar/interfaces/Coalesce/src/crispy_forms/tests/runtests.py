#!/usr/bin/env python

import os

os.system('python runtests_bootstrap.py')
os.system('python runtests_uniform.py')
